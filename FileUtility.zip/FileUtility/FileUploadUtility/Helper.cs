﻿using Aspose.Cells;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FileUploadUtility
{
    public class Helper
    {
        public void ProcessFile (string inputFilePath,string inputOrgName, string inputFileext)
        {
            // inputFilePath = @"xxx\xxxx\xxxxxx\xxxxxx\xxxxx.csv";
            ////allowed input org name for csv : BOA,CAPITALONE,DCU,AXIS .  For Excel : ICICI,HDFC.
            //inputOrgName = "ICICI";
            //inputFileext = "excel";
            // end 

            if (inputFileext.ToLower() == "excel")
            {

                Workbook wb = new Workbook(inputFilePath);

                // Get all worksheets
                WorksheetCollection collection = wb.Worksheets;
                if (inputOrgName.ToUpper() == "ICICI")
                {
                    CreateDataTable(wb, inputOrgName);
                }
                else
                {
                    CreateDataTableForHDFC(wb, "HDFC");
                }
            }

            if (inputFileext.ToLower() == "csv")
            {
                FetcDataFromCSV(inputFilePath, inputOrgName);
            }


        }

        public void CreateDataTable(Workbook wb, string bankId)
        {
            try
            {

                int worksheetcount = wb.Worksheets.Count;


                WorksheetCollection collection = wb.Worksheets;
                //Microsoft.Office.Interop.Excel.Worksheet wks = (Microsoft.Office.Interop.Excel.Worksheet)wb.Worksheets[1];
                //string firstworksheetname = wks.Name;

                //statement get the first cell value  
                for (int worksheetIndex = 0; worksheetIndex < collection.Count; worksheetIndex++)
                {

                    // Get worksheet using its index
                    Worksheet worksheet = collection[worksheetIndex];

                    // Print worksheet name
                    Console.WriteLine("Worksheet: " + worksheet.Name);

                    // Get number of rows and columns
                    int rows = worksheet.Cells.MaxDataRow;
                    int cols = worksheet.Cells.MaxDataColumn;
                    DataTable dataTable = new DataTable();
                    //start and end Datatable 
                    int startIndex = 0;
                    int endIndex = 0;

                    // Loop through rows
                    for (int i = 0; i < rows; i++)
                    {
                        if (endIndex > 0)
                        {
                            continue;
                        }
                        DataRow dr = dataTable.NewRow();
                        // Loop through each column in selected row
                        for (int j = 0; j <= cols; j++)
                        {

                            if (worksheet.Cells[i, j].Value != null && bankId == "ICICI"
                                && (worksheet.Cells[i, j].Value).ToString().Trim().ToLower() == "s no.")
                            {
                                startIndex = 1;

                            }

                            if (worksheet.Cells[i, j].Value != null && bankId == "ICICI" && (worksheet.Cells[i, j].Value).ToString().Trim().ToLower().Contains("legends"))
                            {
                                endIndex = 1;

                            }

                            if (startIndex == 1)
                            {
                                DataColumn dc = new DataColumn();
                                dc.ColumnName = (worksheet.Cells[i, j].Value).ToString().Trim().ToLower();
                                dc.DataType = typeof(String);
                                dataTable.Columns.Add(dc);
                            }

                            if (startIndex > 1 && endIndex < 1 && j > 0)
                            {
                                dr[j - 1] = (worksheet.Cells[i, j].Value).ToString();
                            }


                        }
                        if (startIndex == 1)
                        { startIndex = 2; }
                        if (startIndex == 2 && endIndex < 1)
                        {
                            dataTable.Rows.Add(dr);
                        }


                        // Print line break
                        Console.WriteLine(" ");
                    }
                    DataTable newDT = ConvertDataIntoStorageFormat(dataTable, bankId);
                    StoreInDb(newDT, "TransactionDetails");
                }
                
            }
            catch (Exception ex)
            { 
              Console.WriteLine(ex.Message);
            }

        }
        public void CreateDataTableForHDFC(Workbook wb, string bankId)
        {
            try
            {
                int worksheetcount = wb.Worksheets.Count;


                WorksheetCollection collection = wb.Worksheets;
                //Microsoft.Office.Interop.Excel.Worksheet wks = (Microsoft.Office.Interop.Excel.Worksheet)wb.Worksheets[1];
                //string firstworksheetname = wks.Name;

                //statement get the first cell value  
                for (int worksheetIndex = 0; worksheetIndex < collection.Count; worksheetIndex++)
                {

                    // Get worksheet using its index
                    Worksheet worksheet = collection[worksheetIndex];

                    // Print worksheet name
                    Console.WriteLine("Worksheet: " + worksheet.Name);

                    // Get number of rows and columns
                    int rows = worksheet.Cells.MaxDataRow;
                    int cols = worksheet.Cells.MaxDataColumn;
                    DataTable dataTable = new DataTable();
                    //start and end Datatable 
                    int startIndex = 0;
                    int endIndex = 0;

                    // Loop through rows
                    for (int i = 0; i < rows; i++)
                    {
                        if (endIndex > 0)
                        {
                            continue;
                        }
                        DataRow dr = dataTable.NewRow();
                        // Loop through each column in selected row
                        for (int j = 0; j <= cols; j++)
                        {

                            if (i == 20 && worksheet.Cells[i, j].Value != null && bankId == "HDFC")

                            {
                                startIndex = 1;

                            }

                            if (startIndex == 2 && i >= 22 && worksheet.Cells[i, j].Value != null && bankId == "HDFC" && (worksheet.Cells[i, j].Value).ToString().Contains("********"))
                            {
                                endIndex = 1;

                            }

                            if (startIndex == 1 && !(worksheet.Cells[i, j].Value).ToString().Contains("********"))
                            {
                                DataColumn dc = new DataColumn();
                                dc.ColumnName = (worksheet.Cells[i, j].Value).ToString().Trim().ToLower();
                                dc.DataType = typeof(String);
                                dataTable.Columns.Add(dc);
                            }

                            if (i >= 23 && startIndex > 1 && endIndex < 1 && (worksheet.Cells[i, j].Value) != null)
                            {
                                dr[j] = (worksheet.Cells[i, j].Value).ToString();
                            }


                        }
                        if (startIndex == 1)
                        { startIndex = 2; }
                        if (startIndex == 2 && endIndex < 1)
                        {
                            dataTable.Rows.Add(dr);
                        }


                        // Print line break
                        Console.WriteLine(" ");
                    }
                    DataTable newDT = ConvertDataIntoStorageFormat(dataTable, bankId);
                    StoreInDb(newDT, "TransactionDetails");
                }

            }
            catch (Exception ex)
            { 
             Console.WriteLine(ex.Message);
            }

        }

        public void FetcDataFromCSV(string filepath, string bankId)
        {
            try
            {
                StreamReader reader = null;
                DataTable dataTable = new DataTable();

                //Instantiate LoadOptions specified by the LoadFormat.
                LoadOptions loadOptions = new LoadOptions(LoadFormat.Csv);

                //Create a Workbook object and opening the file from its path
                Workbook wb = new Workbook(filepath, loadOptions);

                int startIndex = 0;
                int endIndex = 0;
                string startText = ConfigurationManager.AppSettings[bankId + "_Text"];
                if (File.Exists(filepath))
                {
                    reader = new StreamReader(File.OpenRead(filepath));
                    List<string> listA = new List<string>();
                    while (!reader.EndOfStream)
                    {
                        if (startIndex == 1)
                            startIndex = 2;

                        var line = reader.ReadLine();
                        //var values = line.Split('\"');
                        Regex CSVParser = new Regex(",(?=(?:[^\"]*\"[^\"]*\")*(?![^\"]*\"))");
                        String[] values = CSVParser.Split(line);
                        if (values.Any(cus => cus.Contains(startText)))
                        {
                            startIndex = 1;
                            for (int i = 0; i < values.Count(); i++)
                            {
                                DataColumn dc = new DataColumn();
                                dc.ColumnName = values[i].ToString().Trim().Replace("\"", "");
                                dc.DataType = typeof(String);
                                dataTable.Columns.Add(dc);
                            }

                        }
                        else if (startIndex < 1)
                        {
                            continue;
                        }

                        if (startIndex == 2)
                        {

                            DataRow row = dataTable.NewRow();
                            for (int i = 0; i < values.Count(); i++)
                            {
                                row[i] = values[i];
                            }
                            dataTable.Rows.Add(row);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("File doesn't exist");
                }
               DataTable newDT =  ConvertDataIntoStorageFormat(dataTable, bankId);
               StoreInDb(newDT, "TransactionDetails");
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public DataTable CreateDataTable()
        { 
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("TransDate", typeof(String)));
            dt.Columns.Add(new DataColumn("Description", typeof(String)));
            dt.Columns.Add(new DataColumn("Balance", typeof(Double)));
            dt.Columns.Add(new DataColumn("Debit", typeof(Double)));
            dt.Columns.Add(new DataColumn("Credit", typeof(Double)));
            dt.Columns.Add(new DataColumn("ChequeNo", typeof(String)));
            dt.Columns.Add(new DataColumn("BankName", typeof(String)));

            return dt;

        }

        public void StoreInDb(DataTable dt, string TableName)
        {
            try
            {
                string connString = ConfigurationManager.ConnectionStrings["ConnString"].ConnectionString;

                using (SqlConnection cn = new SqlConnection(connString))
                {
                    string sql = "Select * from " + TableName;
                    SqlDataAdapter da = new SqlDataAdapter(sql, connString);
                    SqlCommandBuilder cb = new SqlCommandBuilder(da);
                    da.Update(dt);
                    dt.AcceptChanges();


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }

        }

        public DataTable ConvertDataIntoStorageFormat(DataTable fileData, string bankName)
        {
            DataTable dt = CreateDataTable();
            try
            {
                string col_prefix = bankName + "_Col";
                foreach (DataRow dr in fileData.Rows)
                {
                    if ((bankName == "ICICI" || bankName == "HDFC") && dr[ConfigurationManager.AppSettings[col_prefix + "_Date"]].ToString() == "")
                    {
                        continue;
                    }
                    DataRow drnew = dt.NewRow();
                    drnew["BankName"] = bankName;
                    drnew["TransDate"] = dr[ConfigurationManager.AppSettings[col_prefix + "_Date"]].ToString();
                    drnew["Description"] = dr[ConfigurationManager.AppSettings[col_prefix + "_Description"]].ToString();
                    if (ConfigurationManager.AppSettings[col_prefix + "_ChequeNo"] != "NA")
                    {
                        drnew["ChequeNo"] = dr[ConfigurationManager.AppSettings[col_prefix + "_ChequeNo"]].ToString();
                    }
                    else {
                        drnew["ChequeNo"] = "";
                    }
                    bool isDebitCreditInSameCol = Convert.ToBoolean(ConfigurationManager.AppSettings[col_prefix + "_IsDebitCreditInSameCol"]);


                    var debit = dr[ConfigurationManager.AppSettings[col_prefix + "_Debit"]].ToString().Replace("\"","").Replace("$", "");
                    if (debit != null && debit != "")
                    {
                        double debitValue = Convert.ToDouble(debit);

                        if (bankName == "CAPITALONE")
                        {
                            if (dr[ConfigurationManager.AppSettings[col_prefix + "_Type"]].ToString() == "Credit")
                            {
                                drnew["Credit"] = debitValue;
                            }
                            else if (dr[ConfigurationManager.AppSettings[col_prefix + "_Type"]].ToString() == "Debit")
                            {
                                drnew["Debit"] = debitValue;
                            }
                        }
                        else
                        {
                            if (debitValue > 0)
                            {
                                drnew["Debit"] = debitValue;
                            }
                            if (debitValue < 0)
                            {
                                drnew["Credit"] = debitValue;
                            }
                        }

                    }
                    if (!isDebitCreditInSameCol)
                    {
                        var credit = dr[ConfigurationManager.AppSettings[col_prefix + "_Credit"]].ToString().Replace("\"", "").Replace("$", "");
                        if (credit != null && credit != "")
                        {
                            drnew["Credit"] = Convert.ToDouble(credit);
                        }
                    }
                    var balance = dr[ConfigurationManager.AppSettings[col_prefix + "_Balance"]].ToString().Replace("\"", "").Replace("$", "");
                    if (balance != null && balance != "")
                    {
                        drnew["Balance"] = Convert.ToDouble(balance);
                    }
                    dt.Rows.Add(drnew);
                }

                
            }
            catch (Exception ex)
            { 
            Console.WriteLine(ex.Message);
            }
            return dt;
        }

    }
}
