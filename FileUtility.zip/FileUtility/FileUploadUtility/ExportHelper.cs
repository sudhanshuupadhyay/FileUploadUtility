﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace FileUploadUtility
{
    internal class ExportHelper
    {
        //ImportXml File Path 
        static string filePath = @"ImportFile.txt";

        //Exported Xml File Path
        static string inputFilePath = @"C:\Users\sudhanshu.upadhyay\Downloads\TallyTrials-20220819T104559Z-001\TallyTrials\Data\AllVouchersTransactions_trimmed.xml";
        //ConnString
        static string connString = ConfigurationManager.AppSettings["ConnString"];
        public static void CreateImportVoucher(int isImport)
        {
            try
            {
                //Tp Create Voucher for Import 
                if (isImport == 1)
                {
                    createImportVoucher();
                    return;
                }

                //To Insert Export FileData
                DataSet ds = new DataSet();
                //ENVELOPE objxml = new ENVELOPE();
                XmlDocument doc = new XmlDocument();
                doc.Load(inputFilePath);

                string json = JsonConvert.SerializeXmlNode(doc);

                JObject Jo = JObject.Parse(json);
                //objxml = (ENVELOPE)JsonConvert.DeserializeObject<ENVELOPE>(json);
                string key = "VOUCHER";
                var children = Jo.Children().Children().Children().Children().Children().Children().Children().Children().Children().Children().Children();
                DataTable dtVoucher = new DataTable();
                int cnt = 1;

                // Default ColumnsFor AllLedgerEntriesList
                int subcnt = 1;

                DataTable dtAllLedgerEntriesList = new DataTable();
                var dc = new DataColumn("TRANSINDEX", typeof(int));
                dtAllLedgerEntriesList.Columns.Add(dc);
                var dc1 = new DataColumn("VOUCHERGUID", typeof(String));
                dtAllLedgerEntriesList.Columns.Add(dc1);

                //Default ColumnsForBankAllocation.List
                DataTable dtBankAllocationsList = new DataTable();
                int subsubCnt = 1;
                var dcBAL = new DataColumn("TRANSINDEX", typeof(int));
                dtBankAllocationsList.Columns.Add(dcBAL);
                var dcBAL1 = new DataColumn("VOUCHERGUID", typeof(String));
                dtBankAllocationsList.Columns.Add(dcBAL1);
                foreach (var child in children)
                {
                    int transIndexcntforBAL = 1;
                    int transIndexcntForLedger = 1;
                    if (child.GetType().Name.ToString() == "JProperty" && ((JProperty)child).Name == "SVCURRENTCOMPANY")
                    {
                        continue;
                    }
                    if (((JObject)child).Type.ToString() == "Object")
                    {
                        foreach (JToken jto in child.Children())
                        {
                            if ((((JProperty)jto).Name) == "VOUCHER")
                            {

                                foreach (var jprop in jto)
                                {
                                    DataRow dr = dtVoucher.NewRow();
                                    foreach (var jfield in jprop.Children())
                                    {
                                        if (((JProperty)jfield).Name.ToString() == "ALLLEDGERENTRIES.LIST")
                                        {

                                            foreach (var jsubfield in jfield.Children())
                                            {
                                                foreach (var element in jsubfield)
                                                {
                                                    DataRow drAllLedgerEntriesList = dtAllLedgerEntriesList.NewRow();

                                                    foreach (var subelement in element.Children())
                                                    {
                                                        //if (((JProperty)subelement).Name.ToString() == "OLDAUDITENTRYIDS.LIST" || ((JProperty)subelement).Name.ToString() == "OLDAUDITENTRYIDS.LIST")
                                                        //{
                                                        //    continue;
                                                        //}
                                                        if (((JProperty)subelement).Name.ToString() == "BANKALLOCATIONS.LIST")
                                                        {

                                                            DataRow drBankAllocationsList = dtBankAllocationsList.NewRow();
                                                            foreach (var jbalelement in subelement.Children().Children())
                                                            {
                                                                if (subsubCnt == 1)
                                                                {
                                                                    var dcbal2 = new DataColumn(((JProperty)jbalelement).Name.ToString(), typeof(String));
                                                                    dtBankAllocationsList.Columns.Add(dcbal2);
                                                                }
                                                                if (dtBankAllocationsList.Columns.Contains(((JProperty)jbalelement).Name.ToString()))
                                                                {
                                                                    drBankAllocationsList[((JProperty)jbalelement).Name.ToString()] = ((JProperty)jbalelement).Value.ToString();
                                                                }
                                                                else
                                                                {
                                                                    var dcbal2 = new DataColumn(((JProperty)jbalelement).Name.ToString(), typeof(String));
                                                                    dtBankAllocationsList.Columns.Add(dcbal2);
                                                                    drBankAllocationsList[((JProperty)jbalelement).Name.ToString()] = ((JProperty)jbalelement).Value.ToString();

                                                                }


                                                            }
                                                            drBankAllocationsList["TRANSINDEX"] = transIndexcntforBAL;
                                                            drBankAllocationsList["VOUCHERGUID"] = dr["GUID"].ToString();
                                                            subsubCnt++;
                                                            transIndexcntforBAL++;
                                                            dtBankAllocationsList.Rows.Add(drBankAllocationsList);

                                                        }
                                                        else
                                                        {
                                                            if (subcnt == 1)
                                                            {
                                                                var dc2 = new DataColumn(((JProperty)subelement).Name.ToString(), typeof(String));
                                                                dtAllLedgerEntriesList.Columns.Add(dc2);
                                                            }
                                                            if (dtAllLedgerEntriesList.Columns.Contains(((JProperty)subelement).Name.ToString()))
                                                            {
                                                                drAllLedgerEntriesList[((JProperty)subelement).Name.ToString()] = ((JProperty)subelement).Value.ToString();
                                                            }
                                                            else
                                                            {
                                                                var dc2 = new DataColumn(((JProperty)subelement).Name.ToString(), typeof(String));
                                                                dtAllLedgerEntriesList.Columns.Add(dc2);
                                                                drAllLedgerEntriesList[((JProperty)subelement).Name.ToString()] = ((JProperty)subelement).Value.ToString();

                                                            }
                                                        }
                                                    }
                                                    drAllLedgerEntriesList["TRANSINDEX"] = transIndexcntForLedger;
                                                    drAllLedgerEntriesList["VOUCHERGUID"] = dr["GUID"].ToString();
                                                    subcnt++;
                                                    transIndexcntForLedger++;
                                                    dtAllLedgerEntriesList.Rows.Add(drAllLedgerEntriesList);
                                                }
                                            }

                                        }
                                        else
                                        {
                                            if (cnt == 1)
                                            {
                                                var dcVoucher = new DataColumn(((JProperty)jfield).Name.ToString(), typeof(String));
                                                dtVoucher.Columns.Add(dcVoucher);
                                            }
                                            if (dtVoucher.Columns.Contains(((JProperty)jfield).Name.ToString()))
                                            {
                                                dr[((JProperty)jfield).Name.ToString()] = ((JProperty)jfield).Value.ToString();
                                            }
                                            else
                                            {
                                                var dcVoucher = new DataColumn(((JProperty)jfield).Name.ToString(), typeof(String));
                                                dtVoucher.Columns.Add(dcVoucher);
                                                dr[((JProperty)jfield).Name.ToString()] = ((JProperty)jfield).Value.ToString();

                                            }

                                        }
                                    }

                                    dtVoucher.Rows.Add(dr);

                                }
                            }
                        }
                        //var result = child
                        // var mydict = JsonConvert.DeserializeObject<Dictionary<string, string>>(child);
                    }
                    cnt++;


                }
                StoreInDb(dtVoucher, "VOUCHER");
                StoreInDb(dtAllLedgerEntriesList, "AllLedgerEntriesList");
                StoreInDb(dtBankAllocationsList, "BankAllocationsList");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }
        }
        public static void StoreInDb(DataTable dt, string TableName)
        {
            try
            {


                using (SqlConnection cn = new SqlConnection(connString))
                {
                    string sql = "Select * from " + TableName;
                    SqlDataAdapter da = new SqlDataAdapter(sql, connString);
                    SqlCommandBuilder cb = new SqlCommandBuilder(da);
                    da.Update(dt);
                    dt.AcceptChanges();


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
            }

        }
        public static DataTable GetDBData()
        {
            //string connString = @"Data Source=SUDHANSHU-UPADH;Initial Catalog=Demo;Integrated Security=True";
            DataTable dt = new DataTable();
            using (SqlConnection cn = new SqlConnection(connString))
            {

                string sql = "Select * from [dbo].[vw_VoucherExport]";
                SqlDataAdapter da = new SqlDataAdapter(sql, connString);
                da.Fill(dt);
            }
            return dt;
        }

        public static void createImportVoucher()
        {
            Root rootObj = new Root();
            ENVELOPE nVELOPE = new ENVELOPE();
            HEADER header = new HEADER();
            BODY bODY = new BODY();
            DATA dATA = new DATA();
            List<TALLYMESSAGE> tmsgList = new List<TALLYMESSAGE>();
            // List<VOUCHER> voucherList = new List<VOUCHER>();


            DataTable dt = GetDBData();

            var grpList = from g in dt.AsEnumerable()
                          group g by g.Field<string>("VOUCHERGUID") into b
                          select b.ToList();

            header.VERSION = 1;
            header.ID = "Vouchers";
            header.TYPE = "Data";
            header.TALLYREQUEST = "Import";

            foreach (var grp in grpList)
            {
                TALLYMESSAGE tmsg = new TALLYMESSAGE();
                VOUCHER voucher = new VOUCHER();
                List<ALLLEDGERENTRIESLIST> aLLLEDGERENTRIESLISTs = new List<ALLLEDGERENTRIESLIST>();
                List<VOUCHER> voucherList = new List<VOUCHER>();

                int grpCnt = 1;
                foreach (var record in grp)
                {
                    if (grpCnt == 1)
                    {
                        voucher.DATE = Convert.ToInt32(record["DATE"].ToString());
                        voucher.NARRATION = record["NARRATION"].ToString();
                        voucher.VOUCHERTYPENAME = record["VOUCHERTYPENAME"].ToString();
                        voucher.VOUCHERNUMBER = Convert.ToInt32(record["VOUCHERNUMBER"]);
                    }
                    ALLLEDGERENTRIESLIST el = new ALLLEDGERENTRIESLIST();
                    el.LEDGERNAME = record["LEDGERNAME"].ToString();
                    el.ISDEEMEDPOSITIVE = record["ISDEEMEDPOSITIVE"].ToString();
                    el.AMOUNT = Convert.ToDecimal(record["AMOUNT"]);
                    aLLLEDGERENTRIESLISTs.Add(el);
                }
                voucher.ALLLEDGERENTRIESLIST = aLLLEDGERENTRIESLISTs;
                voucherList.Add(voucher);
                tmsg.VOUCHER = voucherList;
                tmsgList.Add(tmsg);


            }





            dATA.TALLYMESSAGE = tmsgList;
            bODY.DATA = dATA;
            nVELOPE.BODY = bODY;
            nVELOPE.HEADER = header;
            rootObj.ENVELOPE = nVELOPE;




            string jsonString = JsonConvert.SerializeObject(rootObj);


            XmlDocument doc = new XmlDocument();
            //doc.Load(jsonString);
            doc = JsonConvert.DeserializeXmlNode(jsonString);


            using (StreamWriter sw = File.CreateText(filePath))
            {

                sw.WriteLine(doc.InnerXml);

            }


        }
    }
    
}
