﻿namespace FileUploadUtility
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFilePath = new System.Windows.Forms.TextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.txtOrgName = new System.Windows.Forms.ComboBox();
            this.txtFormat = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.saveData = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "File Path";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Org Name";
            // 
            // txtFilePath
            // 
            this.txtFilePath.Location = new System.Drawing.Point(162, 49);
            this.txtFilePath.Name = "txtFilePath";
            this.txtFilePath.Size = new System.Drawing.Size(549, 26);
            this.txtFilePath.TabIndex = 2;
            this.txtFilePath.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtOrgName
            // 
            this.txtOrgName.FormattingEnabled = true;
            this.txtOrgName.Items.AddRange(new object[] {
            "BOA",
            "CAPITALONE",
            "DCU",
            "AXIS",
            "ICICI",
            "HDFC"});
            this.txtOrgName.Location = new System.Drawing.Point(162, 97);
            this.txtOrgName.Name = "txtOrgName";
            this.txtOrgName.Size = new System.Drawing.Size(549, 28);
            this.txtOrgName.TabIndex = 4;
            this.txtOrgName.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // txtFormat
            // 
            this.txtFormat.FormattingEnabled = true;
            this.txtFormat.Items.AddRange(new object[] {
            "Excel",
            "CSV"});
            this.txtFormat.Location = new System.Drawing.Point(162, 141);
            this.txtFormat.Name = "txtFormat";
            this.txtFormat.Size = new System.Drawing.Size(549, 28);
            this.txtFormat.TabIndex = 5;
            this.txtFormat.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(37, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Format";
            // 
            // saveData
            // 
            this.saveData.Location = new System.Drawing.Point(162, 195);
            this.saveData.Name = "saveData";
            this.saveData.Size = new System.Drawing.Size(75, 28);
            this.saveData.TabIndex = 7;
            this.saveData.Text = "Save";
            this.saveData.UseVisualStyleBackColor = true;
            this.saveData.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1706, 450);
            this.Controls.Add(this.saveData);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFormat);
            this.Controls.Add(this.txtOrgName);
            this.Controls.Add(this.txtFilePath);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "/";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtFilePath;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.ComboBox txtOrgName;
        private System.Windows.Forms.ComboBox txtFormat;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button saveData;
    }
}

