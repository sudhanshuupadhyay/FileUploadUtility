﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileUploadUtility
{
    internal class Import
    {
    }
    public class ALLLEDGERENTRIESLIST
    {
        public string LEDGERNAME { get; set; }
        public string ISDEEMEDPOSITIVE { get; set; }
        public decimal AMOUNT { get; set; }
    }

    public class BODY
    {
        public string DESC { get; set; }
        public DATA DATA { get; set; }
    }

    public class DATA
    {
        public List<TALLYMESSAGE> TALLYMESSAGE { get; set; }
    }

    public class ENVELOPE
    {
        public HEADER HEADER { get; set; }
        public BODY BODY { get; set; }
    }

    public class HEADER
    {
        public int VERSION { get; set; }
        public string TALLYREQUEST { get; set; }
        public string TYPE { get; set; }
        public string ID { get; set; }
    }

    public class Root
    {
        public ENVELOPE ENVELOPE { get; set; }
    }

    public class TALLYMESSAGE
    {
        public List<VOUCHER> VOUCHER { get; set; }
    }

    public class VOUCHER
    {
        public int DATE { get; set; }
        public string NARRATION { get; set; }
        public string VOUCHERTYPENAME { get; set; }
        public int VOUCHERNUMBER { get; set; }

        [JsonProperty("ALLLEDGERENTRIES.LIST")]
        public List<ALLLEDGERENTRIESLIST> ALLLEDGERENTRIESLIST { get; set; }
    }
}
